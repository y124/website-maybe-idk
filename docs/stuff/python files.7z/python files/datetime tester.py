from time import *
SavedTime = int(time())
def UpdateAutoclicker():
    global SavedTime
    ADDED = 0 - (SavedTime - int(time()))
    SavedTime = int(time())
    print(ADDED)

while True:
    e = input('a: ')
    if e == '1':
        UpdateAutoclicker()
