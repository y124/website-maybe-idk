import requests
import bs4
a = []
url = 'https://novels80.com/i-am-number-four/page-1-133993.html'


def rget(url):
    return requests.get(f'{url}')


def findnextpage(text):
    soup = bs4.BeautifulSoup(text, features="lxml")
    if 'javascript:void(0)' == soup.find('a', {'id': 'next_chap'})['href']:
        return None
    try:
        return 'https://novels80.com' + soup.find('a', {'id': 'next_chap'})['href']
    except:
        return None

    
def getwords(url):
    text = rget(url).text
    soup = bs4.BeautifulSoup(text, features="lxml")
    x = soup.find('p')
    x = str(x).split(f'\n')
    x2 = []
    for count in range(int(len(x)/2)):
        x2.append(x[count*2+1][:-5])
    return x2


print(getwords(url))


print(url)
while url is not None:
    a.append(url)
    url = findnextpage(rget(url).text)
    print(url)
for count in range(10):
    print()
print(a)
