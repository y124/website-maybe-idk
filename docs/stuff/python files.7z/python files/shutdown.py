from pynput.keyboard import Key, Controller
from time import *
k = Controller()
k.press(Key.cmd)
k.press('x')
k.release('x')
k.release(Key.cmd)
sleep(0.05)
k.press('u')
k.release('u')
k.press('u')
k.release('u')
