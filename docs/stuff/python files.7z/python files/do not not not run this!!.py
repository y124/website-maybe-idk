from pynput.mouse import Button, Controller
from random import *
from time import *
mouse = Controller()
def pos(per2x, per2y):
    x = int(per2x*12.8)
    y = int(per2y*7.2)
    mouse.position = (x, y)
while True:
    pos(randint(0, 100), randint(0, 100))
    sleep(2)
    mouse.press(Button.left)
    mouse.release(Button.left)
    mouse.press(Button.left)
    mouse.release(Button.left)
