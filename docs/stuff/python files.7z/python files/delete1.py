from pynput.keyboard import Key, Controller
from random import *
from time import *
k = Controller()
def p(key1):
    k.press(key1)
    k.release(key1)
sleep(1)
k.type(str(randint(100, 999)))
for count in range(9):
    p(str(count + 1))
    for count in range(10):
        p(str(count))
        for count in range(10):
            p(str(count))
            for count in range(10):
                p(str(count))
                for count in range(10):
                    p(str(count))
                    for count in range(10):
                        p(str(count))
                        p(Key.enter)
                    sleep(0.1)
                    p(Key.backspace)
                    p(Key.backspace)
                sleep(1)
                p(Key.backspace)
            p(Key.backspace)
        p(Key.backspace)
    p(Key.backspace)
