import datetime, time
gt = datetime.datetime.now
t1 = gt()
time.sleep(10)
t2 = gt()
print(t2-t1)
