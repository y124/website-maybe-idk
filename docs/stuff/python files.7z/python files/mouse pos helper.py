from pynput.mouse import Button, Controller
from time import *
from random import *
mouse = Controller()
def pos(per2x, per2y):
    x = int(per2x*12.8)
    y = int(per2y*7.2)
    mouse.position = (x, y)
for count in range(1000):
    pos(randint(33, 59), randint(30, 82))
    mouse.press(Button.left)
    sleep(0.001)
    mouse.release(Button.left)

