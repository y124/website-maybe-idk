from random import *
c = ''
d = 1
b = True
for count in range(200):
    a = 1
    while b == True:
        if randint(1, 2) == 1:
            a = a + 2 * d
            d += 1
        else:
            b = False
    b = True
    c = c + str(a) + ' ,'
print(c)
