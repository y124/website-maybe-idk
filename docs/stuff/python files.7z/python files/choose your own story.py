from time import *
from random import * 
StillGoing = True
path = 'main'


def p(string):
    print(string)
    sleep(1)
    
    
def X(first_path_name, second_path_name):
    e = input('>>> ')
    print()
    if(e == '1'):
        pathh = first_path_name
    elif(e == '2'):
        pathh = second_path_name
    else:
        pathh = path
        print('error 1: ' + e + ' is not a option, write in 1 or 2 next time')
    return pathh


def Z(first_path_name, second_path_name):
    e = randint(1, 2)
    if(e == 1):
        pathh = first_path_name
    elif(e == 2):
        pathh = second_path_name
    return pathh

    
while(StillGoing == True):
    if(path == 'main'):
        p('you are walking along a road ')
        p('you find yourself at a turnoff')
        p('do you: 1. continue or 2. take the turnoff')
        path = X('1', '2')
        
    elif(path == '1'):
        p('there is a random bus stop on the road')
        p('do you 1. continue along the road or 2. wait for the bus')
        path = X('11', '12')

    elif(path == '11'):
        p('you are still continuing along the road you are very tired')
        p('do you 1. continue walking or 2. stop for a rest')
        path = X('111', '112')

    elif(path == '111'):
        p('you continue walking along the road there is a highway')
        p('do you 1. cross it or 2. take a rest')
        path = X('1111', '1112')

    elif(path == '1111'):
        p('your life is in the hands of fate now will you survive i dont know')
        path = Z('11111', 'Death1')

    elif(path == '11111'):
        p('you survived well done! ')
        p('but you are still tired and hungery')
        p('do you 1. check supplys or 2. take a nap')
        path = X('111111', '111112')

    elif(path == '111111'):
        p('you remember you have no supplys')
        p('do you 1. try to get home before you die of hunger')
        p('or 2. try to find a village in time')
        path = X('1111111', '1111112')

    elif(path == 'Death2'):
        print('your attempt failed, you died of hunger')
        path = 'try again'

    elif(path == 'try again'):
        p('would you like to try again')
        e = input('>>> ')
        if('y' in e.lower()):
           path = 'main'
           for count in range(100):
               print()
        else:
            StillGoing = False

    elif(path == '111112'):
        p('you are now not tired but you are even more hungery')
        p('you also notice because your eyes are less tied a house in the distance')
        p('do you 1. check supplys 2. go to the house')
        path = X('111111', '1111122')

    elif(path == '1111122'):
        p('a nice person lives in the house they give you food and shelter for the night')
        p('you remember you have to go home you say thankyou and goodbye and go back to your house')        
        path = 'home'

    elif(path == 'Death1'):
        print('you were ran over by a car')
        path = 'try again'

    elif(path == '1112'):
        p('you are very hungery')
        p('your now rested keen eyes spot a house across the highway')
        p("it is closer then your house but don't forget about stranger danger")
        p('do you 1. try to get back to your house before you die of hunger')
        p('2. risk the house')
        path = X('11121', '1111122')

    elif(path == '11121'):
        path = Z('Death2', 'home')

    elif(path == 'home'):
        p('well done you made your way home')
        path = 'try again'

    elif(path == '112'):
        p('while you rested you were somehow moved into a grassy area in the middle of nowhere')
        p('you look around and see some food and water but it might be posioned')
        p('do you 1. try to find out who took you here 2. eat the food and drink the water (you are hungery and thresty)')
        path = X('1121', '1122')

    elif(path == '1121'):
        p('you look around and see a house you knock on the door')
        p('There is a psychopath in there that tried to poison you')
        path = 'Death3'

    elif(path == 'Death3'):
        p('the details of your Death were to gory to show here')
        path = 'try again'

    elif(path == '1122'):
        p("the food tastes strange like it was meant to be poisoned but it wasn't")
        p('you see a house')
        p('do you 1. look around 2. go into the house')
        path = X('11221', '1121')

    elif(path == '11221'):
        p('you found the backyard of your home')
        path = 'home'

    elif(path == '12'):
        p('a bus comes')
        p('do you 1. get on it 2. get of the bus stop and walk up the road')
        path = X('121', '111')

    elif(path == '121'):
        p('you go on the bus you are the only one on it')
        p('in 5 minutes the bus driver says "everyone out this is the last stop"')
        p('you are in a small village the sign say is called villtown')
        p('there are a few houses and 2 shops a store and a café')
        p('you are very hungery the walk must have been longer then you thought')
        p('do you 1. go to the café 2. go the store')
        path = X('1211', '1211')

    elif(path == '1211'):
        p('you have eaten your food')
        p('do you 1. go on the bus back to your home 2. stay in the town for a while')
        path = X('12111', '12112')

    elif(path == '12111'):
        p('you go back to your stop on the bus')
        p('do you 1. go home 2. go up the road')
        path = X('home', '111')

    elif(path == '12112'):
        p('you find a forest')
        p('do you 1. go home on the bus 2. go into the forest')
        path = X('home', '121122')

    elif(path == '121122'):
        p('it looks dangerous are you sure')
        p('1. yes 2. no')
        path = X('1211221', 'home')

    elif(path == '1211221'):
        p('you are lost in the forest')
        p('do you want to 1. go left 2. go right')
        path = X('12112211', '12112212')

    elif(path == '12112211'):
        p("you don't find your way home")
        path = 'Death2'

    elif(path == '12112212'):
        p('you find your way to a bus stop')
        path = 'home'

    elif(path == '2'):
        p('you take the turn off')
        p('there is a bush track on the side of it')
        p('do you 1. continue on the road you are on or 2. go on the bush track')
        path = X('21', '22')

    elif(path == '21'):
        p('you are very tired')
        p('there is a bus stop just up the road')
        p('do you 1. continue 2. rest at the bus stop')
        path = X('211', '212')
        
    elif(path == '211'):
        p('you have reached the end of the road')
        p('you see a factory in the distance')
        p('do you 1. continue into the forest 2. go into the factory')
        path = X('2111', '2112')

    elif(path == '2111'):
        p('it looks dangerous are you sure')
        p('1. yes 2. no')
        path = X('1211221', '2112')

    elif(path == '2112'):
        p('you go in the factory there is a door marked "staff only"')
        p('do you 1. go in the door or 2. continue though the factory')
        path = X('21121', '21122')

    elif(path == '21121'):
        p('you go in the staff only room')
        p('there is a office and a machine')
        p('do you 1. go look at the machine or 2. go in the office ')
        path = X('211211', '211212')

    elif(path == '211212'):
        p('the staff room has a person in it they say:')
        p('what are you doing here this is staff only!!')
        p('you leave and go home')
        path = 'home'

    elif(path == '21122'):
        p('you find a small shop in it selling pillows')
        p('you buy one as a souvenir and then go home')
        path = 'home'

    elif(path == '211211'):
        p('you go look at the machine it look interesting but dangerous')
        p('do you want to take a closer look 1. yes or 2. no go to the office')
        path = X('2112111', '211212')

    elif(path == '2112111'):
        p('you take a closer look')
        p('the machine grabs on to your hand probobly mistaking it for what it is making')
        path = 'Death3'

    elif(path == '212'):
        p('you are resting when a bus comes')
        p('do you 1. continue walking on the road or 2. get on the bus')
        path = X('211', '2122')

    elif(path == '2122'):
        p('the bus stops at a bus stop near a road')
        p('do you 1. get off and start walking up the road or 2. stay on the bus')
        path = X('11', '121')

    elif(path == '22'):
        p('you walk up the bush track')
        p('there is a intersection')
        p('do you 1. go left or 2. go right')
        path = X('221', '222')

    elif(path == '221'):
        p('you go left and walk up the path')
        p('you are very tired and hungery')
        p('do you 1. continue or 2. rest')
        path = X('2211', '2212')

    elif(path == '2211'):
        p('you are very hungery if you do not find food soon you will DIE')
        p('there is an intersection')
        p('do you 1. go left or 2. go right')
        path = X('22111', 'Death2')

    elif(path == '22111'):
        p('you find a town called villtown')
        p('there are a few houses and 2 shops a store and a café')
        p('do you 1. eat at the café or 2. buy some food from the store and eat there')
        path = X('1211', '1211')

    elif(path == '2212'):
        p('you rested')
        p('do you 1. continue or 2. go back')
        path = X('2211', '22')

    elif(path == '222'):
        p('you go right')
        p('there is another intersection')
        p('do you 1. go left or 2. go right')
        path = X('22111', '2222')

    elif(path == '2222'):
        p('you go right it was a long walk')
        p('you are very hungery you find a house')
        p('do you 1. try to get home in time 2. knock on the door of the house')
        path = X('1111111', '22222')

    elif(path == '22222'):
        p('noone answers')
        p('do you 1. investagate or 2. try to get home')
        path = X('222221', '1111111')

    elif(path == '222221'):
        p('the house is full of old stuff')
        p('you see a path down to a basement')
        p('do you 1. leave or 2. go into the basement')
        path = X('1111111', '2222212')

    elif(path == '2222212'):
        p('there is a person in the basement')
        path = Z('22222121', '22222122')

    elif(path == '22222121'):
        p('they are a psychopath')
        path = 'Death3'

    elif(path == '22222122'):
        p('luckly they are nice and help you get home')
        path = 'home'

    elif(path == '1111111'):
        path = Z('home', 'Death2')

    elif(path == '1111112'):
        path = Z('Death2', '22111')
        
    else:
        p('error 2: part of story not programed yet')
        p('Restarting sorry for any inconvince this may have caused')
        path = 'main'
        
