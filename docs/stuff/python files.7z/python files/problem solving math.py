def contine():
    global l, w, b
    if l > w:
        l = l - w
        b = b + w
    else:
        w = w - l
        b = b + l
    if 0 not in [l, w]:
        contine()
    else:
        print(b)
while True:        
    a = input('l, w\n>>> ').split(', ')
    l = int(a[0])
    w = int(a[1])
    b = 0
    contine()
