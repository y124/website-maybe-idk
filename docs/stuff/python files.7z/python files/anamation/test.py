from time import *
from needed import *
t = 0
setas(1, 1, 's')
printall()
for count in range(10):
    print('')
for count in range(10):
    t = t + 1
    for count in range(10):
        setas(count, t, 's')
        printall()
        setas(count, t, 't')
        sleep(0.25)
