input('hello and welcome to... ')
input('my LINK progect on coding')
input('This code is a calculator')
e = input('do you have any questions for it (supports bodmas!!)? ')
def plus(num, num1):
    num2 = num + num1
    return num2
def minus(num, num1):
    num2 = num - num1
    return num2
def times(num, num1):
    num2 = num*num1
    return num2
def divide(num, num1):
    num2 = num/num1
    return num2
def power(num, num1):
    num2 = 1
    for count in range(num1):
        num2 = times(num, num2)
    return num2

        
def B1(string):
    ba = 0
    for count in range(len(string)):
        if(ord(string[count]) == ord('(')):
           openb = count
           ba = ba + 1
        if(ord(string[count]) == ord(')')):
           closeb = count
    try:
        c = closeb - openb
    except:
        c = 0
    insidebrakets = ''
    for count in range(c - 1):
        temp = string[count + openb + 1]
        insidebrakets = insidebrakets + temp
    return insidebrakets, ba

def B(string):
    tempvar1 = True
    while tempvar1 == True:
        ILBs, AoBs = B1(string)
        LoIBB = []
        if ILBs == '':
            print('brakets solved!')
            tempvar1 = False
        else:
            LoIBB.append(ILBs)

def O(lists):
    for count in range(len(lists)):
        if(ord(lists[count]) == ord('^')):
           openb = count

print(B(e))
