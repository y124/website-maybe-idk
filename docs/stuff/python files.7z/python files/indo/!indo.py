from tkinter import *
from tkinter.font import Font
from PIL import Image, ImageTk
root = Tk()
def load(this):
    pass

def show(imag, lbls, after, before):
    global img, img1
    img = Image.open(imag+'.png')
    img1 = ImageTk.PhotoImage(img)
    f = Font(family='Courier New', size=25)
    btn = Button(root, width=250, height=250, font=f, image=img1)
    btn.grid(row=0, column=0)
    x = 0
    for lbl in lbls:
        x += 1
        lbl2 = Label(text=lbl, font=f)
        lbl2.grid(row=x, column=0)
    n = Button(root, font=f, text='>')
    n.grid(row=0, column=2)
    b = Button(root, font=f, text='<')
    b.grid(row=0, column=1)

test = [
    '1',
    '2'
    ]
test2 = 'img1'
show(test2, test, '', '')

root.mainloop()
