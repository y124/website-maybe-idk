from random import *
e = input("convert to sarcasm: ")
a = ''
e = e.lower()
for count in range(len(e)):
    b = e[count]
    if randint(1, 2) == 2:
        b = b.upper()
    a = a + b
    try:
        if e[count + 1] == e[count]:
            if randint(1, 2) == 2:
                b = b.upper()
            a = a + b
        if e[count + 1] == e[count]:
            if randint(1, 2) == 2:
                b = b.upper()
    except:
        a = a
        a = a + b
a = '"' + a + '"'
input(a)
