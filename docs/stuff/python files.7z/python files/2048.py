from pynput.keyboard import Key, Controller
from time import *
from random import *

sleep(1)
k = Controller()

for count in range(1000000):
    c = [Key.down, Key.left, Key.up][randint(0, 2)]
    k.press(c)
    k.release(c)
