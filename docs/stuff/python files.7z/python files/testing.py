from pynput.keyboard import Key, Controller
keyboard = Controller()
name1 = input('full name (eg: firstname lastname) ')
name2 = name1.split(' ')
username = name2[0][0:4] + name2[1][0:4]

