from random import *
w = ''
c = 0
letters = 'qwertyuiopasdfghjklzxcvbnm'
punt = ",;:"
puntend = ".?!"
f = randint(25, 35)
# 15-25 sent 1/5 chance 4 punt after word word 3-7 letters long
for count in range(f):
    c = c + 1
    b = ''
    for count in range(randint(3, 7)):
        a = letters[randint(0, 25)]
        b = b + a
    if((randint(1, 5) == 5) and (c < (f - 4))):
        b = b + punt[randint(0, 2)]
    if(f != c):
        b = b + ' '
    w = w + b
w = w + puntend[randint(0, 2)]
print(w)
