while True:
    e = input('')
    e = e.split(', ')
    b = int(e[0]) + int(e[1]) + int(e[2])
    print(str(360 - b))
