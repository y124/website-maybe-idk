#importing stuff
from tkinter import *
from tkinter import messagebox
from tkinter.ttk import *
from tkinter.font import Font
from random import *

BuyMax = False

def strr(bob):
    if int(bob) < 0:
        bob = 0
    if bob < 10000000000000:
        bob = int(100*bob)/100
    if bob == int(bob):
        bob = int(bob)
    if bob > 1000000:
        bobEX = len(str(int(bob))) - 1
        bob = bob/(10**len(str(int(bob))) - 1)
        bob = str(int(bob*1000)/100) + 'e' + str(bobEX)
    return str(bob)

# import save
save = open('items.txt', 'r') 
items = save.read().split('\n')
save.close()
coin = float(items[1])
common = float(items[2])
uncommon = float(items[3])
rare = float(items[4])
epic = float(items[5])
legendary = float(items[6])

LUCK = int(items[8])
TimesUncommon = int(items[12])
LLUCK = float(items[13])

Shards = float(items[19])
Furnaces = float(items[20])
Factorys = float(items[21])

FM = 5 ** Furnaces

def FurnaceC():
    global coin
    global common
    global uncommon
    global rare
    global epic
    global legendary
    global LUCK
    global LLUCK
    global TwoXClick
    global MoreCoins
    global TwoXItems
    global TimesUncommon
    global Furnaces
    global FM
    global progress
    global progress2
    if coin < 1000000*FM:
        messagebox.showerror("Not Enough", "You Do Not Have Enough Coins To Do This\nMaybe Wait For The Bar To Fill")
    else:
        if messagebox.askokcancel("Reset for furnace?", 'Are you sure you want to reset game?\nFor a furnace', default="cancel", icon="warning"):
            if coin >= 1000000*FM:
                Furnaces += 1
            coin = 0
            common = 0
            uncommon = 0
            rare = 0
            epic = 0
            legendary = 0
            LUCK = 0
            LLUCK = 0
            TwoXClick = 0
            MoreCoins = 0
            TwoXItems = 0
            TimesUncommon = 0
    FM = 5 ** Furnaces
    progress2["maximum"] = 1000000*FM
    progress["maximum"] = len(str(int(1000000*FM)))
    UpdateGUI()
            

def sel():
    global BuyMax
    if(str(var.get()) == '1'):
        BuyMax = False
    else:
        BuyMax = True
    
def luck():
    global progress
    global coin
    global LUCK
    global BuyMax
    global LLUCK
    LM = 1.02
    L2 = LUCK+LLUCK*100
    if BuyMax == True:
        while coin >= int(100*(LM**L2)):
            L2 = LUCK+LLUCK*100
            coin = coin - int(100*(LM**L2))
            if LUCK < 1000:
                LUCK += 1
            else:
                LLUCK += 0.01
    else:        
        if coin >= int(100*(LM**L2)):
            L2 = LUCK+LLUCK*100
            coin = coin - int(100*(LM**L2))
            if LUCK < 1000:
                LUCK += 1
            else:
                LLUCK += 0.01
    L2 = LUCK+LLUCK*100
    lbl21.configure(text= f'increses luck\nCurrent luck: +{strr(LUCK)}\nCost {strr(int(100*(1.02**L2)))} Coins\nYou earn Legendary Luck when over 1000 Luck\nCurrent Legendary Luck {strr(LLUCK*100)}')
    lbl1.configure(text=strr(coin))
    progress['value'] = len(str(int(coin)))
    progress2['value'] = int(coin)
    
TwoXClick = int(items[9]) 
def a2xClick():
    LM = 1.01
    global common
    global TwoXClick
    global BuyMax
    if BuyMax == False:
        if common >= int(10*(LM**TwoXClick) + TwoXClick/10):
            common = common - int(10*(LM**TwoXClick) + TwoXClick/10)
            TwoXClick += 1
    else:
        while common >= int(10*(LM**TwoXClick) + TwoXClick/10):
            common = common - int(10*(LM**TwoXClick) + TwoXClick/10)
            TwoXClick += 1
    lbl22.configure(text=f'+ 1% chance to click twice\nCurrent Chance: {strr(TwoXClick)}%\nCost {strr(int(10*(1.01**TwoXClick) + TwoXClick/10))} Commons')
    lbl2.configure(text=strr(common))

def a100xClick():
    global progress
    global coin
    global common
    global uncommon
    global rare
    global epic
    global legendary
    global LUCK
    global BuyMax
    global TimesUncommon
    asd = 0
    
    if (10 + (TimesUncommon*(TimesUncommon+1)/2)) <= uncommon:
        uncommon -= 10 + (TimesUncommon*(TimesUncommon+1)/2)
        TimesUncommon += 1
        for count in range(100):
            loot = randint(1, 10000)
            if loot > 1000 + LUCK*16:
                coin += 1
            elif loot > 250 + LUCK*8:
                common += 1
            elif loot > 100 + LUCK*4:
                uncommon += 1
            elif loot > 25 + LUCK*2:
                rare += 1
            elif loot > 2:
                epic += 1

    if BuyMax == True:
        if TimesUncommon > 1000000:
            lbl23.configure(text=f'THIS HAS BEEN USED\nTHE MAX AMOUNT OF TIMES')
        else:
            while (10 + (TimesUncommon*(TimesUncommon+1)/2)) <= uncommon:
                uncommon -= 10 + (TimesUncommon*(TimesUncommon+1)/2)
                TimesUncommon += 1
                asd += 1

    if BuyMax == True:
        for count in range(100):
            loot = randint(1, 10000)
            if loot > 1000 + LUCK*16:
                coin += 1*asd
            elif loot > 250 + LUCK*8:
                common += 1*asd
            elif loot > 100 + LUCK*4:
                uncommon += 1*asd
            elif loot > 25 + LUCK*2:
                rare += 1*asd
            elif loot > 2:
                epic += 1*asd
                
    lbl1.configure(text=strr(coin))
    lbl2.configure(text=strr(common))
    lbl3.configure(text=strr(uncommon))
    lbl4.configure(text=strr(rare))
    lbl5.configure(text=strr(epic))
    lbl23.configure(text=f'Instant 100 Clicks\nCost {strr(10 + (TimesUncommon*(TimesUncommon+1)/2))} Uncommons')
    if TimesUncommon > 1000000:
        lbl23.configure(text=f'THIS HAS BEEN USED\nTHE MAX AMOUNT OF TIMES')
    progress['value'] = len(str(int(coin)))
    progress2['value'] = int(coin)

MoreCoins = int(items[10])
def morecoins():
    global rare
    global MoreCoins
    global BuyMax
    if BuyMax == False:
        if rare >= int(1.1**(MoreCoins/10)):
            rare = rare - int(1.1**(MoreCoins/10))
            MoreCoins += 1
    else:
        while rare >= int(1.1**(MoreCoins/10)):
            rare = rare - int(1.1**(MoreCoins/10))
            MoreCoins += 1
    lbl24.configure(text=f'+ 1% chance to gain an extra coin every tap\nCurrent Chance: {strr(MoreCoins)}%\nCost {strr(int(1.1**(MoreCoins/10)))} Rares')
    lbl4.configure(text=strr(rare))

def multiply():
    global progress
    global coin
    global common
    global rare
    global epic
    global BuyMax
    CL = False
    CL2 = False
    RL = False
    if epic < 2:
        a = 0
    elif BuyMax == True:
        a = int(epic/2)
    else:
        a = 1
    for count in range(a):
        epic -= 2
        if CL == False:
            if coin < 250:
                coin = coin * 2
            else:
                coin += 250 * (a - count)
                CL = True
        
        if CL2 == False:    
            if common < 50:
                common = common * 2
            else:
                common += 50 * (a - count)
                CL2 = True

        if RL == False:
            if rare < 10:
                rare = rare * 2
            else:
                rare += 10 * (a - count)
                RL = True
                
        if [RL, CL, CL2] == [True, True, True]:
            if BuyMax == True:
                epic = epic - int(epic/2)*2
            break
    lbl5.configure(text=strr(epic))
    lbl1.configure(text=strr(coin))
    lbl2.configure(text=strr(common))
    lbl4.configure(text=strr(rare))
    progress['value'] = len(str(int(coin)))
    progress2['value'] = int(coin)
    
TwoXItems = int(items[11])
def a2xItems():
    global TwoXItems
    global legendary
    global BuyMax
    if BuyMax == False:
        if legendary >= 2 ** TwoXItems:
            legendary = legendary - 2 ** TwoXItems
            TwoXItems = TwoXItems + 1
    else:
        while legendary >= 2 ** TwoXItems:
            legendary = legendary - 2 ** TwoXItems
            TwoXItems = TwoXItems + 1
    lbl26.configure(text=f'1.2x all clicks\nCurrent Multiplyer x{strr(1.2 ** TwoXItems)}\nCost {strr(2 ** TwoXItems)} Legendarys')
    lbl6.configure(text=strr(legendary))

root = Tk()
myFont = Font(family="Times New Roman", size=25)
myFontSmall = Font(family="Times New Roman", size=15)
ShowItems = Toplevel(root)
Upgrades = Toplevel(root)

w1 = items[15]
w2 = items[16]
w3 = items[17]

root.geometry(w1)
ShowItems.geometry(w2)
Upgrades.geometry(w3)

# empty command for buttons that do nothing
def empty():
    return

# random loot
def clicked():
    global coin
    global progress
    global common
    global uncommon
    global rare
    global epic
    global legendary
    global LUCK
    global TwoXClick
    global TwoXItems
    global MoreCoins
    global Furnaces
    global Shards
    
    TXC = TwoXClick
    Twice = int(TXC/100)
    e = TXC - Twice*100
    if randint(1, 100) < e:
        Twice = Twice + 1
    Twice = Twice + 1
        
    for count in range(Twice):
        
        MC = MoreCoins
        COINS = int(MC/100)
        e = MC - COINS*100
        if randint(1, 100) < e:
            COINS = COINS + 1.2**TwoXItems * (Shards + 1)
        coin = coin + COINS
            
        loot = randint(1, 10000)
        if loot > 1000 + LUCK*16:
            coin += 1 * 1.2**TwoXItems * (Shards + 1)
        elif loot > 250 + LUCK*8:
            common += 1 * 1.2**TwoXItems * (Shards + 1)
        elif loot > 100 + LUCK*4:
            uncommon += 1 * 1.2**TwoXItems * (Shards + 1)
        elif loot > 25 + LUCK*2:
            rare += 1 * 1.2**TwoXItems * (Shards + 1)
        elif loot > 2 + LLUCK:
            epic += 1 * 1.2**TwoXItems * (Shards + 1)
        else:
            legendary += 1.2**TwoXItems * (Shards + 1)

    Shards = Shards + Furnaces/100
    UpdateGUI()

def save():
    global coin
    global common
    global uncommon
    global rare
    global epic
    global legendary
    global LUCK
    global TwoXClick
    global TwoXItems
    global MoreCoins
    global w1
    global w2
    global w3
    global Shards
    global Furnaces
    global Factorys
    w1 = ('+' + '+'.join([str(root.winfo_x()), str(root.winfo_y())]))
    w2 = ('+' + '+'.join([str(ShowItems.winfo_x()), str(ShowItems.winfo_y())]))
    w3 = ('+' + '+'.join([str(Upgrades.winfo_x()), str(Upgrades.winfo_y())]))
    file = open('items.txt', 'w')
    file.write('ITEMS (index 1 - 6)' + '\n')
    file.write(str(coin) + '\n')
    file.write(str(common) + '\n')
    file.write(str(uncommon) + '\n')
    file.write(str(rare) + '\n')
    file.write(str(epic) + '\n')
    file.write(str(legendary) + '\n')
    file.write('UPGRADES (index 8 - 13)' + '\n')
    file.write(str(LUCK) + '\n')
    file.write(str(TwoXClick) + '\n')
    file.write(str(MoreCoins) + '\n')
    file.write(str(TwoXItems) + '\n')
    file.write(str(TimesUncommon) + '\n')
    file.write(str(LLUCK) + '\n')
    file.write('Window Positions (index 15 - 17) (+0+0)' + '\n')
    file.write(str(w1) + '\n')
    file.write(str(w2) + '\n')
    file.write(str(w3) + '\n')
    file.write('PRESTIGE (index 19 - 21)' + '\n')
    file.write(str(Shards) + '\n')
    file.write(str(Furnaces) + '\n')
    file.write(str(Factorys) + '\n')
    file.close()

def UpdateGUI():
    global coin
    global common
    global uncommon
    global rare
    global epic
    global legendary
    global LUCK
    global LLUCK
    global TwoXClick
    global TwoXItems
    global MoreCoins
    global TimesUncommon
    global Shards
    global Furnaces
    global Factorys
    global progress
    global progress2

    L2 = LUCK+LLUCK*100

    lbl26.configure(text=f'1.2x all clicks\nCurrent Multiplyer x{strr(1.2 ** TwoXItems)}\nCost {strr(2 ** TwoXItems)} Legendarys')
    lbl24.configure(text=f'+ 1% chance to gain an extra coin every tap\nCurrent Chance: {strr(MoreCoins)}%\nCost {strr(int(1.1**(MoreCoins/10)))} Rares')
    lbl23.configure(text=f'Instant 100 Clicks\nCost {strr(10 + (TimesUncommon*(TimesUncommon+1)/2))} Uncommons')
    lbl22.configure(text=f'+ 1% chance to click twice\nCurrent Chance: {strr(TwoXClick)}%\nCost {strr(int(10*(1.01**TwoXClick) + TwoXClick/10))} Commons')
    lbl21.configure(text= f'increses luck\nCurrent luck: +{strr(LUCK)}\nCost {strr(int(100*(1.02**L2)))} Coins\nYou earn Legendary Luck when over 1000 Luck\nCurrent Legendary Luck {strr(LLUCK*100)}')
    lbl6.configure(text=strr(legendary))
    lbl1.configure(text=strr(coin))
    lbl2.configure(text=strr(common))
    lbl3.configure(text=strr(uncommon))
    lbl4.configure(text=strr(rare))
    lbl5.configure(text=strr(epic))
    lbl31.configure(text=strr(Shards))
    lbl32.configure(text=strr(Furnaces))
    lbl33.configure(text=strr(Factorys))
    progress['value'] = len(str(int(coin)))
    progress2['value'] = int(coin)

# Click Button Setup
photo = PhotoImage(file = r"Click.png")
btn=Button(root, command = clicked, width=10, image=photo)
btn.grid(row=0, column=0)
lbl = Label(text='Click!')
lbl.grid(row=1, column=0)
lbl.configure(font=myFont)

photoo = PhotoImage(file = r"Save.png")
btn=Button(root, command = save, width=10, image=photoo)
btn.grid(row=0, column=1)
lbl = Label(text='Save!')
lbl.grid(row=1, column=1)
lbl.configure(font=myFont)

#Prestige Menu Setup
PrestigeMenu = Toplevel(root)
photo17 = PhotoImage(file = r"Shard.png")
PrestigeMenu.iconphoto(False, photo17)
PrestigeMenu.title('Prestige')

lbl40 = Label(PrestigeMenu, text='Progress To Prestige\nFor Furnace')
lbl40.configure(font=myFont)
lbl40.grid(row=0, column=1)

lbl40 = Label(PrestigeMenu, text='Furnaces Make\nShards On Click\nShards Multiply\nClick Rewards')
lbl40.configure(font=myFontSmall)
lbl40.grid(row=0, column=2)

lbl40 = Label(PrestigeMenu, text='Logarithmic')
lbl40.configure(font=myFontSmall)
lbl40.grid(row=2, column=0)

lbl40 = Label(PrestigeMenu, text='Normal')
lbl40.configure(font=myFontSmall)
lbl40.grid(row=1, column=0)

progress2 = Progressbar(PrestigeMenu, length = 300)
progress2["maximum"] = 1000000*FM
progress2['value'] = int(coin)
progress2.grid(row=1, column=1)

progress = Progressbar(PrestigeMenu, length = 300)
progress["maximum"] = len(str(int(1000000*FM)))
progress['value'] = len(str(int(coin)))
progress.grid(row=2, column=1)

photo40 = PhotoImage(file = r"Furnace.png")
btn40 = Button(PrestigeMenu, command = FurnaceC, image=photo40)
btn40.grid(row=3, column=1)

lbl41 = Label(PrestigeMenu, text=f'Reset to\nGain\nFurnace')
lbl41.configure(font=myFont)
lbl41.grid(row=3, column=0)

#Items List
photo1 = PhotoImage(file = r"Coin.png")

root.iconphoto(False, photo1)
ShowItems.iconphoto(False, photo1)
Upgrades.iconphoto(False, photo1)

root.title('Clicker')
ShowItems.title('Items')
Upgrades.title('Upgrades')

btn=Button(ShowItems, command = empty, width=10, image=photo1)
btn.grid(row=0, column=0)
lbl1 = Label(ShowItems, text=strr(coin))
lbl1.grid(row=0, column=1)
lbl1.configure(font=myFont)

photo2 = PhotoImage(file = r"Common.png")
btn=Button(ShowItems, command = empty, width=10, image=photo2)
btn.grid(row=1, column=0)
lbl2 = Label(ShowItems, text=strr(common))
lbl2.grid(row=1, column=1)
lbl2.configure(font=myFont)

photo3 = PhotoImage(file = r"Uncommon.png")
btn=Button(ShowItems, command = empty, width=10, image=photo3)
btn.grid(row=2, column=0)
lbl3 = Label(ShowItems, text=strr(uncommon))
lbl3.grid(row=2, column=1)
lbl3.configure(font=myFont)

photo4 = PhotoImage(file = r"Rare.png")
btn=Button(ShowItems, command = empty, width=10, image=photo4)
btn.grid(row=0, column=3)
lbl4 = Label(ShowItems, text=strr(rare))
lbl4.grid(row=0, column=4)
lbl4.configure(font=myFont)

photo5 = PhotoImage(file = r"Epic.png")
btn=Button(ShowItems, command = empty, width=10, image=photo5)
btn.grid(row=1, column=3)
lbl5 = Label(ShowItems, text=strr(epic))
lbl5.grid(row=1, column=4)
lbl5.configure(font=myFont)

photo6 = PhotoImage(file = r"Legendary.png")
btn=Button(ShowItems, command = empty, width=10, image=photo6)
btn.grid(row=2, column=3)
lbl6 = Label(ShowItems, text=strr(legendary))
lbl6.grid(row=2, column=4)
lbl6.configure(font=myFont)

#Upgrades List
photo21 = PhotoImage(file = r"Luck.png")
btn=Button(Upgrades, command = luck, width=10, image=photo21)
btn.grid(row=0, column=0)

lbl21 = Label(Upgrades, text= f'increses luck\nCurrent luck: +{strr(LUCK)}\nCost {strr(int(100*(1.02**(LUCK+LLUCK*100))))} Coins\nYou earn Legendary Luck when over 1000 Luck\nCurrent Legendary Luck {strr(LLUCK*100)}')
lbl21.grid(sticky = W, row=0, column=1)
lbl21.configure(font=myFontSmall)



photo22 = PhotoImage(file = r"2xClick.png")
btn=Button(Upgrades, command = a2xClick, width=10, image=photo22)
btn.grid(row=1, column=0)

lbl22 = Label(Upgrades, text=f'+ 1% chance to click twice\nCurrent Chance: {strr(TwoXClick)}%\nCost {strr(int(10*(1.01**TwoXClick) + TwoXClick/10))} Commons')
lbl22.grid(sticky = W, row=1, column=1)
lbl22.configure(font=myFontSmall)



photo23 = PhotoImage(file = r"100xClick.png")
btn=Button(Upgrades, command = a100xClick, width=10, image=photo23)
btn.grid(row=2, column=0)

lbl23 = Label(Upgrades, text=f'Instant 100 Clicks\nCost {strr(10 + (TimesUncommon*(TimesUncommon+1)/2))} Uncommons')
if TimesUncommon > 1000000:
    lbl23.configure(text=f'THIS HAS BEEN USED\nTHE MAX AMOUNT OF TIMES')
lbl23.grid(sticky = W, row=2, column=1)
lbl23.configure(font=myFontSmall)



photo24 = PhotoImage(file = r"MoreCoins.png")
btn=Button(Upgrades, command = morecoins, width=10, image=photo24)
btn.grid(row=0, column=3)

lbl24 = Label(Upgrades, text=f'+ 1% chance to gain an extra coin every tap\nCurrent Chance: {strr(MoreCoins)}%\nCost {strr(int(1.1**(MoreCoins/10)))} Rares')
lbl24.grid(sticky = W, row=0, column=4)
lbl24.configure(font=myFontSmall)



photo25 = PhotoImage(file = r"Multiply.png")
btn=Button(Upgrades, command = multiply, width=10, image=photo25)
btn.grid(row=1, column=3)

lbl25 = Label(Upgrades, text=f'2x Coins, Commons and Rares\n(up to 250, 50 and 10)\nCost 2 Epics')
lbl25.grid(sticky = W, row=1, column=4)
lbl25.configure(font=myFontSmall)



photo26 = PhotoImage(file = r"2xItems.png")
btn=Button(Upgrades, command = a2xItems, width=10, image=photo26)
btn.grid(row=2, column=3)

lbl26 = Label(Upgrades, text=f'1.2x all clicks\nCurrent Multiplyer x{strr(1.2 ** TwoXItems)}\nCost {strr(2 ** TwoXItems)} Legendarys')
lbl26.grid(sticky = W, row=2, column=4)
lbl26.configure(font=myFontSmall)



photo31 = PhotoImage(file = r"Shard.png")
btn=Button(ShowItems, command = empty, width=10, image=photo31)
btn.grid(row=0, column=5)

lbl31 = Label(ShowItems, text=f'{strr(Shards)}')
lbl31.grid(sticky = W, row=0, column=6)
lbl31.configure(font=myFont)



photo32 = PhotoImage(file = r"Furnace.png")
btn=Button(ShowItems, command = empty, width=10, image=photo32)
btn.grid(row=1, column=5)

lbl32 = Label(ShowItems, text=f'{strr(Furnaces)}')
lbl32.grid(sticky = W, row=1, column=6)
lbl32.configure(font=myFont)



photo33 = PhotoImage(file = r"Factory.png")
btn=Button(ShowItems, command = empty, width=10, image=photo33)
btn.grid(row=2, column=5)

lbl33 = Label(ShowItems, text=f'{strr(Factorys)}')
lbl33.grid(sticky = W, row=2, column=6)
lbl33.configure(font=myFont)



lbl34 = Label(Upgrades, text=f'Buy Amount')
lbl34.grid(sticky = W, row=3, column=0)
var = IntVar()
R1 = Radiobutton(Upgrades, text="1", variable=var, value=1, command=sel)
R1.grid(sticky = W, row=3, column=1)
R2 = Radiobutton(Upgrades, text="MAX", variable=var, value=2, command=sel)
R2.grid(row=3, column=2)

root.mainloop()
