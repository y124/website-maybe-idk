q = input("percentige (%) or decimal (.) or fracion (-) ")
per = 100
dec = 1.0
fra_n = 1
fra_d = 1
fradebug = ''
Mixnum = 0

if q == '%':
 per = int(input("amount of percent "))
 dec = per/100
 fra_n = per
 fra_d = 100
   
if q == '.':
 dec_s = input('number before point ')
 dec_e = input('number after point ')
 dec = dec_s  + '.' + dec_e
 if len(dec_e) > 2:
   fradebug = len(dec_e) - 2
   fradebug = fradebug*'0'
 dec = float(dec)
 per = dec*100
 fra_n = per
 fra_d = 100
 
if q == '-':
 a = input("Mixed Numeral (mn) or Inproper Fraction/Fraction (f): ")
 if a == "mn":
   Mixnum = int(input('Number: '))
 fra_n = int(input("numerator: "))
 fra_d = int(input("denominator: "))
 dec = fra_n/fra_d + Mixnum
 fra_n = fra_n + fra_d*Mixnum
 per = dec*100

fra_n = float(fra_n)  
fra_d = float(fra_d)
for count in range(len(fradebug)):
 fra_n = fra_n*10
 fra_d = fra_d*10
 
fn = fra_n
z = True
fra_n = int(fra_n)
fra_d = int(fra_d)
fn = int(fn)
while z:
 try:
   if(fra_n/fn == int(fra_n/fn) and fra_d/fn == int(fra_d/fn)):
     fra_n = fra_n/fn
     fra_d = fra_d/fn
     z = False
   fn = fn - 1
   if fn == 0:
     z = False
 except ZeroDivisionError:
   fra_n = 0
   fra_d = 1
   z = False

fra_nmn = int(fra_n)
fra_dmn = int(fra_d)
 
mixnum = int(dec)
for count in range(mixnum):
 fra_nmn = fra_nmn - fra_dmn
 
chn = mixnum
if dec - mixnum >= 0.5:
 chn = chn + 1

if per == float(int(per)):
 per = int(per)

if fra_d > fra_n:
    fra_h = int(fra_d)
else:
    fra_h = int(fra_n)
 
fra_n = int(fra_n)
fra_d = int(fra_d)
for count in range(20):
 print('')
 
print("Percentige: " + str(per) + '%')
print('')
print("Decimal: " + str(dec))
if mixnum != 0:
 print('')
 print('Mixed Numeral:')
 print('')
 print("  " + len(str(mixnum))*' ' + str(fra_nmn))
 print(str(mixnum) + "  " + '_'*len(str(fra_dmn)))
 print("  " + len(str(mixnum))*' ' + str(fra_dmn))
print('')
text = 'Improper '
if mixnum == 0:
 text = ''
print(text + 'Fraction:')
print('')
print(str(fra_n))
print('_'*len(str(fra_h)))
print(str(fra_d))
print('')
if(float(mixnum) == dec):
 print('Number: ' + str(mixnum))
else:
 print('Closest whole number: ' + str(chn))
input('')
