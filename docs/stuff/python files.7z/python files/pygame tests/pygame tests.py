import pygame
from tkinter import *
from tkinter.colorchooser import *
from PIL import Image, ImageDraw
root = Tk()
ke = 8
i = 'red'
speed = 3
pygame.init()
screen = pygame.display.set_mode((1080,720))
F3 = (0, 0)
def move(x, y):
    global F3
    global bg
    global image, i2
    #screen.blit(bg, F3)
    i2 = i2.move(x, y)
    screen.blit(image, i2)
    pygame.display.update()
def main():
    global speed
    global ke
    global F3
    global bg
    global image, i2
    global i
    image = pygame.image.load(r'r.png')
    i2 = image.get_rect()
    bg = pygame.image.load(r'bg.jpg')
    screen.blit(bg, (0, 0))
    screen.blit(image, F3)
    pygame.time.delay(10) 
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        keys = pygame.key.get_pressed()
        if keys[pygame.K_s]:
            move(0, speed)
        if keys[pygame.K_a]:
            move(0 - speed, 0)
        if keys[pygame.K_w]:
            move(0, 0 - speed)
        if keys[pygame.K_d]:
            move(speed, 0)
        if keys[pygame.K_r]:
            image = pygame.image.load(r'r.png')
            move(0, 0)
            i = 'red'
        if keys[pygame.K_g]:
            image = pygame.image.load(r'g.png')
            move(0, 0)
            i = 'green'
        if keys[pygame.K_b]:
            image = pygame.image.load(r'b.png')
            move(0, 0)
            i = 'blue'
        if keys[pygame.K_c]:
            image = pygame.image.load(r'w.png')
            move(0, 0)
            i = 'white'
        pygame.display.update()
        if keys[pygame.K_e]:
            i = askcolor()[1]
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)
            
        if keys[pygame.K_1]:
            ke = 1
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_2]:
            ke = 2
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_3]:
            ke = 3
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_4]:
            ke = 4
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_5]:
            ke = 5
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_6]:
            ke = 6
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_7]:
            ke = 7
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_8]:
            ke = 8
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_9]:
            ke = 9
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed),1 + int(speed),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_0]:
            ke = 10
            image = Image.new('RGB', (10*ke, 10*ke), color = i)
            img1 = ImageDraw.Draw(image)
            img1.rectangle((1 + int(speed-1),1 + int(speed-1),10*ke-2-(speed+1),10*ke-2-(speed+1)), fill='black')
            mode = image.mode
            size = image.size
            data = image.tobytes()
            image = pygame.image.fromstring(data, size, mode)

        if keys[pygame.K_n]:
            speed -= 0.01
        if keys[pygame.K_m]:
            speed += 0.01
if __name__=="__main__":
    main()
