from quizport import *
from datetime import datetime
print('Welcome to Math Quiz Custom')
num = int(input('What is the highest answer i should give you: '))
qs = int(input('Ok and how many questions: '))
a = datetime.now()
score = 0 #the rest is mainly copy-pasted from times table chalange
for count in range(qs):
    score = randquiz(num, score, 6)
b = datetime.now()
time = b - a
time = str(time)
tim = time.split(':')
time = tim[2]
if tim[1] != '00' or tim[0] != '0':
    time = tim[1] + ':' + time
if tim[0] != '0':
    time = tim[0] + ':' + time    
c = ''
for count in range(len(time) - 4):
    c = c + time[count]
time = c
print()
if len(time) == 5:
    print('you got ' + str(score) + '/' + str(qs) + ' in ' + time + ' seconds')
if len(time) == 8:
    print('you got ' + str(score) + '/' + str(qs) + ' in ' + time + ' minutes')
if len(time) == 10:
    print('you got ' + str(score) + '/' + str(qs) + ' in ' + time + ' hours')
