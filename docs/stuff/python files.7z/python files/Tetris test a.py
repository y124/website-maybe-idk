size = 3
h = 18
w = 10
bl = True
tickv = 0
ground = []
# fix S Difficulty = (2/5)
# make W Difficulty = (4/5)
# add new blocks Difficulty = (1/5)
# points + delete rows Difficulty = (3.5/5)
from random import *
from tkinter import *
from datetime import datetime
now = datetime.now
root = Tk()
textinput = Toplevel(root)
aaa = Text(textinput, font=("Comic Sans MS", 100), width=1,height=1)
aaa.grid(row=0, column=0)
rows = []
grid = []
for i in range(h):
    rows.append(Frame(root))
a = 0
for row in rows:
    a += 1
    row.grid(row=a, column=0)
    grid.append([])
    b = 0
    for count in range(w):
        b += 1
        grid[a-1].append(Label(row, text='', width=size*2, height=size))
        grid[a-1][b-1].grid(row=0, column=b)

def color(x, y, clr):
    global grid
    grid[y - 1][x - 1]['bg'] = clr

for c in grid[2]:
    c['bg'] = '#BBBBBB'
for c in grid[1]:
    c['bg'] = '#BBBBBB'
for c in grid[0]:
    c['bg'] = '#BBBBBB'

blocks = [[(4, 1), (5, 1), (4, 2), (5, 2)], [(4, 1), (4, 2), (4, 3), (5, 3)]]

def tick():
    global grid
    global bl
    global block
    global tickv
    global ground
    global aaa
    for r in grid:
        for c in r:
            if c['bg'] is not 'white':
                c['bg'] = 'white'
    for c in grid[2]:
        if c['bg'] is not '#BBBBBB':
            c['bg'] = '#BBBBBB'
    for c in grid[1]:
        if c['bg'] is not '#BBBBBB':
            c['bg'] = '#BBBBBB'
    for c in grid[0]:
        if c['bg'] is not '#BBBBBB':
            c['bg'] = '#BBBBBB'
    
    tickv += 1
    if bl == True:
        block = choice(blocks)
        bl = False
    for a in block:
        if grid[a[1] - 1][a[0] - 1]['bg'] != 'blue':
            color(a[0], a[1], 'blue')
    if tickv % 5 == 0:
        block2 = []
        for a in block:
            block2.append((a[0], a[1] + 1))
            if a[1] == 18:
                bl = True
        block = block2
    for a in block:
        for ba in ground:
            if (a[1] >= ba[1]) and (a[0] == ba[0]):
                bl = True
    if bl == True:
        for b in block:
            ground.append((b[0], b[1] - 1))
    for a in ground:
        if grid[a[1] - 1][a[0] - 1]['bg'] != 'green':
            color(a[0], a[1], 'green')
    root.after(100, tick)
    if aaa.get('1.0',END)[:-1] is not '':
        for xx in aaa.get('1.0',END)[:-1]:
            if xx in ['w', 'a', 's', 'd']:
                if xx == 'a':
                    check = True
                    for a in block:
                        if a[0] <= 1:
                            check = False
                    if check:
                        block2 = []
                        for a in block:
                            block2.append((a[0] - 1, a[1]))
                        block = block2
                if xx == 'd':
                    check = True
                    for a in block:
                        if a[0] >= 10:
                            check = False
                    if check:
                        block2 = []
                        for a in block:
                            block2.append((a[0] + 1, a[1]))
                        block = block2
                if xx == 's':
                    block2 = []
                    for a in block:
                        block2.append((a[0], a[1] + 1))
                        if a[1] == 18:
                            bl = True
                    block = block2
    aaa.delete('1.0', END)
    
tick()
root.mainloop()
