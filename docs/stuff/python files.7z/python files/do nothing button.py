from tkinter import *
from tkinter.ttk import *
from PIL import Image
img = Image.open(r'C://Users/Benjamin Fraga/Downloads/Raw Images Media/DSC_0012.NEF')
img.show()
root = Tk()
photo = PhotoImage(file = r'C://Users/Benjamin Fraga/Downloads/Raw Images Media/DSC_0012.NEF')
Button(image = photo, width = 20, height = 10, font=("ubuntu mono", 25), bg='#555', fg='#fff').grid(row = 0, column = 0)
