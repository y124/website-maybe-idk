from pynput import key
key = Controller()
key.type(Key.cmd)
