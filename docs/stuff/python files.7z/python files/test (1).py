while True:
    e = int(input("num "))
    d = e
    c = e + 1
    b = c*d
    print(str(b*2))
