from pynput.keyboard import Key, Controller
from time import *
k = Controller()
def p(key1):
    k.press(key1)
    k.release(key1)
sleep(5)
while True:
    k.type('no one like angus rose')
    p(Key.enter)
    sleep(0.1)
