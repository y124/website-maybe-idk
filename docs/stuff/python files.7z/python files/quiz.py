from random import *

def root(num):
    e = 1
    num = int(num)
    num2 = 0
    while num != num2:
        e = e + 1
        num2 = num/e
        if int(num2) == int(e):
            num2 = num
        if int(num/2) != num/2:
            num = num + 1
    return e


def times(num, p):
    e = root(num)
    a = randint(1, e)
    b = randint(1, e)
    e = input("What is " + str(a) + "x" + str(b) + "? ")
    if str(a*b) == e:
        p = p + 1
    return p


def plus(num, p):
    a = randint(1, num)
    b = randint(1, (num - a))
    e = input("What is " + str(a) + "+" + str(b) + "? ")
    if str(a+b) == e:
        p = p + 1
    return p


def minus(num, p):
    a = randint(1, num)
    b = randint(1, a)
    e = input("What is " + str(a) + "-" + str(b) + "? ")
    if str(a-b) == e:
        p = p + 1
    return p


def divide(num, p):
    v = 0
    a = randint(1, num)
    b = randint(1, a)
    while v == 0:
        if a/b == float(int(a/b)) and int(a/b) != 1 and int(a/b) != a:
            e = input("What is " + str(a) + "÷" + str(b) + "? ")
            if str(int(a/b)) == e:
                p = p + 1
            v = 1
        else:
            a = randint(1, num)
            b = randint(1, a)
    return p


def main():
    p = 0
    tries = input("how many questions are in your quiz: ")
    typestr = input('what type of questions (* and or / and or - and or +): ')
    num = int(input('what is your maxumum number: '))
    types = []
    if '+' in typestr:
        types.append('+')
    if '-' in typestr:
        types.append('-')
    if '*' in typestr:
        types.append('*')
    if '/' in typestr:
        types.append('/')
    for count in range(int(tries)):
        f = randint(0, int(len(types) - 1))
        qt = types[f]
        if qt == '*':
            p = times(num, p)
        if qt == '/':
            p = divide(num, p)
        if qt == '+':
            p = plus(num, p)
        if qt == '-':
            p = minus(num, p)
    input("your score is: " + str(p) + "/" + tries)


main()
