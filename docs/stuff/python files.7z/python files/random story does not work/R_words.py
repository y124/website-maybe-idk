nouns = ['diary', 'bottle', 'drop of water', 'box', 'tissue', 'glass', 'watch', 'lolly', 'photo', 'book', 'dog', 'cat', 'wolf', 'tiger', 'dolphin', 'penguin', 'lion', 'horse', 'monkey', 'panda', 'human']
boys_names = ['Liam', 'Noah', 'Michael', 'Logan', 'Matthew', 'James', 'Benjamin', 'Ethan', 'Lucus', 'Jacob']
girls_names = ['Emma', 'Olivia', 'Ava', 'Isabelle', 'Sophie', 'Mia', 'Emily', 'Charlotte', 'Lily', 'Lucy']
hobbies = ['reading', 'watching TV', 'fishing', 'gardening', 'walking', 'shopping', 'traveling', 'bicycling', 'swimming', 'skiing']
