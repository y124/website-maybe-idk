from random import *
from R_words import *


def CC():
    species = nouns[randint(0, (len(nouns) - 1))]
    num_gender = randint(1, 2)
    if num_gender == 1:
        gender = 'boy'
    if num_gender == 2:
        gender = 'girl'
    if gender == 'girl':
        name = girls_names[randint(0, (len(girls_names) - 1))]
    if gender == 'boy':
        name = boys_names[randint(0, (len(boys_names) - 1))]
    age = randint(0, 38)
    hobbie = hobbies[randint(0, (len(hobbies) - 1))]
    if gender == 'boy':
        hisher = 'his'
        heshe = 'he'
    if gender == 'girl':
        hisher = 'her'
        heshe = 'she'
    if age > 17 and gender == 'boy':
        gender2 = 'man'
    elif age > 17 and gender == 'girl':
         gender2 = 'woman'
    else:
        gender2 = gender
    return [species, name, gender2, age, hobbie, hisher, heshe]



