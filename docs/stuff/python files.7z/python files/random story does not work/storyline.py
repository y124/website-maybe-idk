from random import *
from logic import *
#for create_character(CC):
#0 = species, 1 = name, 2 = gender, 3 = age, 4 = hobbie, 5 = hisher, 6 = heshe
#it will be stored as a list ([])

MC = CC()
friend = CC()
friend[4] = MC[4]

def start():
    if randint(1, 2) == 1:
        start1()
    else:
        start2()

logicstart()
def start1():
    input('Once upon a time there was a ' + str(MC[3]) + ' year old ' + MC[0] + ' named ' + MC[1])
    e = randint(1, 1)
    if e == 1:
        f = randint(1, 2)
        if f == 1:
            introfriend1()
        elif f == 2:
            inrtofriend2()

def start2():
    input('one day there was a ' + MC[0] + ' named ' + MC[1] + ' that was ' + str(MC[3]) + ' years old')

def introfriend1():
    input(MC_name + "'s friend was " + friend[1] + ' the ' + friend[0] + ' ' + friend[6] + ' was ' + friend[3] + ' years old')
    friend1 = True
    
def introfriend2():
    input(MC_name + ' had a friend called ' + friend[1] + ' they were a ' + friend[3] + ' year old ' + friend[0])
    friend1 = True
