from random import *
from datetime import datetime
while True:
    t = int(input('What table are you praticing? '))
    a = datetime.now()
    t1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    w = 0
    for count in range(12):
        e = randint(1, len(t1))
        e = e - 1
        f = input('what is ' + str(t1[e]) + 'x' + str(t) + '? ')
        if t1[e]*t != int(f):
            w = w + 1
            print('incorrect answer: 1 minute added to time')
        del t1[e]
    b = datetime.now()
    time = b - a
    time = str(time)
    tim = time.split(':')
    time = tim[2]
    if w != 0:
        x = int(tim[1])
        if w + x > 9:
            tim[1] = str(x + w)
        if w + x < 9:
            tim[1] = '0' + str(x + w)
    if tim[1] != '00' or tim[0] != '0':
        time = tim[1] + ':' + time
    if tim[0] != '0':
        time = tim[0] + ':' + time    
    c = ''
    for count in range(len(time) - 4):
        c = c + time[count]
    time = c
    print()
    if len(time) == 5:
        print('your score: ' + time + ' seconds')
    if len(time) == 8:
        print('your score: ' + time + ' minutes')
    if len(time) == 10:
        print('your score: ' + time + ' hours')
    for count in range(5):
        print()
