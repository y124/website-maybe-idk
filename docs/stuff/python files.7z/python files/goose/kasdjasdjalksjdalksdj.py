from random import *
a = chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90)) + chr(randint(65, 90))
b = input('new txt files be like: ')
f= open(a + ".txt","w")
f.write(b)
f.close()
