from random import *
n1 = randint(1, 12)
n2 = randint(1, 12)
n = 0
b = 0
while(n1 == n2):
    n2 = randint(1, 12)
while(n != n1 and n != n2):
    b = b + n
    n = randint(1, 12)
    
