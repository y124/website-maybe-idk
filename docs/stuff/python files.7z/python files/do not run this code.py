from pynput.mouse import Button, Controller
from time import *
mouse = Controller()
while True:
    for count in range(1000):
        mouse.press(Button.left)
        mouse.release(Button.left)
        sleep(0.0001)
        mouse.position = (10, 20)
