from random import *
for count in range(1000000):
  z = input('Question: ')
  a = ["i don't know", 'probobly not', 'no', 'yes', 'defenitly not', 'defenitly', 'probobly', 'sometimes']
  if 'illuminati' in z or 'CIA' in z or 'FBI' in z or 'MI6' in z:
    print('SHUTING DOWN')
  elif 'pleb' in z:
    print('not as much as plebston playz')
  elif 'idiot' in z:
    print('you mean idint and ' + a[randint(0,9)])
  elif 'how many' in z or 'amount' in z or 'number' in z or 'how old' in z or 'age' in z:
    print(str(randint(-100,100)))
  elif 'poo' in z:
    print('ha ha you said POO')
  elif 'real' in z:
    print('in your imangination')
  elif 'orange' in z:
    print('orange is the best color')
  elif 'star wars' in z:
    print('luke i am your farter')
  elif 'minecraft' in z or 'fortnite' in z:
    print('minecraft is better then fortnite')
  elif 'color' in z or 'colour' in z:
    print('orange is the best colour')
  elif 'worst' in z:
    print("i am NOT the worst you're the WORST")
  elif 'letter' in z or 'abc' in z:
    print(chr(randint(65, 90)))
  elif 'alphabet' in z:
    b = ''   
    for count in range(10000):
      b = b + chr(count + 1)
    print(b)
  elif 'duty' in z or 'dudy' in z:
    print('ha ha you said DUDY')
  elif 'pewdiepie' in z or 't-seires' in z or 'pewds' in z:
    print("sub2pewds and T-seires sucks")
  else:
    print(a[randint(0,7)])
