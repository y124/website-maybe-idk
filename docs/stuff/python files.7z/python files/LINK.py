while True:
    input('hello and welcome to my LINK project on coding')
    input("This code will...")
    input('tell your fortune')
    a = int(input('how old are you '))
    b = ord(input('what is the third letter of your last name (UPPER CASE!) ')) - 64
    c = int(input('what your favorite number between 1 and 20 '))
    d = ord(input('what is your favorite letter in the alphabet (lower case!) ')) - 96
    e = (ord(input('Y/N does 9 + 10 = 21 ')) - 1)/11
    f = (ord(input('Y/N do you like this code ')) - 1)/11
    answer = a + b * (c + d) * (e + f)
    if  (int(answer) < 12000 and int(answer) > 8000):
        ls = 10
    elif(int(answer) < 13000 and int(answer) > 7000):
        ls = 9
    elif(int(answer) < 14000 and int(answer) > 6000):
        ls = 8
    elif(int(answer) < 15000 and int(answer) > 5000):
        ls = 7
    elif(int(answer) < 16000 and int(answer) > 4000):
        ls = 6
    elif(int(answer) < 17000 and int(answer) > 3000):
        ls = 5
    elif(int(answer) < 18000 and int(answer) > 2000):
        ls = 4
    elif(int(answer) < 19000 and int(answer) > 1000):
        ls = 3
    elif(int(answer) < 20000 and int(answer) > 0):
        ls = 2
    else:
        ls = 1
    input('the rest of your life score out of 10 (note this is NOT true) ' + str(ls) + ' :)')
    for count in range(100):
        print()
