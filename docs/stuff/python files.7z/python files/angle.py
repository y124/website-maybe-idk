while True:
    n = int(input('Sides '))
    b = 180*(n - 2)/n
    print(str(b) + ' interal angle')
    print(str(n*b) + ' sum of internal angles')
