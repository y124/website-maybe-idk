# print
# input
# name funtion
# loop
# mutpiply calc
# if elif else and while
# random
# fuction
# tkinter label and button
# tkinter button make number bigger
# tkinter calculator for addition (numbers 0 - 9)
# requests?

print('Hello, World!')

name = input('Name: ')
print(f'Hello, {name}')

for i in range(5):
    print(i)

num1 = input('First Number: ')
num1 = int(num1)
num2 = input('Second Number: ')
num2 = int(num2)
print(f'{num1} x {num2} = {num1 * num2}')

name = input('Name: ')
if name.title() == 'Dally':
    text = 'I Hate You'
elif name.title() == 'Ben':
    text = 'You Are Best'
else:
    text = f'Hi {name}'
print(text)

password = input('Password: ')
while password != '1234':
    password = input('Error wrong password: ')
print('While loop ended')

from random import *
print(randint(1, 10))

def sayhi():
    print('H')
    print('I')
sayhi()
print('Hello')
sayhi()
