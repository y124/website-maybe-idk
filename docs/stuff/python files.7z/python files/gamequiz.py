from quizport import *
from random import *
hardness = input('How hard (0 = too easy, 1 = very easy, 2 = easy, 3 = medium, 4 = hard, 5 = very hard, 6 = impossible)? ')
lvl = 1
def level(lvl):
    hm = 1
    p = 0
    a = ''
    if(hardness == '1'):
        num = lvl+1
        hm = 100
    elif(hardness == '0'):
        num = 2
        hm = 100
    elif(hardness == "2"):
        num = lvl*power_max(lvl*8)
        hm = 10
    elif(hardness == '3'):
        num = (lvl*lvl) + 1
    elif(hardness == '4'):
        num = (lvl + 2)*(lvl + 2)
    elif(hardness == '5'):
        num = lvl*power(2, lvl)
    elif(hardness == '6'):
        num = power(lvl, lvl) + 1
        hm = 0
    countt = power_max(lvl*8)
    if(lvl >= 0*int(hardness)):
        a = a + ' addition'
        types = 1
    if(lvl >= (1*int(hardness) + 1)*hm):
        a = a + " and subtraction"
        types = 2
    if(lvl >= 2*(int(hardness) + 2)*hm - int(hardness)):
        a = a + " and multiplication"
        types = 3
    if(lvl >= 3*(int(hardness) + 2)*hm - int(hardness)):
        a = a + ' and division'
        types = 4
    if(lvl >= 4*(int(hardness) + 2)*hm - int(hardness)):
        a = a + ' and squareroot'
        types = 5
    if(lvl >= 5*(int(hardness) + 2)*hm - int(hardness)):
        a = a + ' and powers'
        types = 6
    print('level ' + str(lvl) + ' this level contains ' + str(countt) + ' questions of ' + a)
    for count in range(countt):
        p = randquiz(num, p, types)
    if p == countt:
        print('Success!')
        lvl = lvl + 1
    else:
        print('Level Failed ' + str(p) + str('/') + str(countt))
    return lvl

while True:
    lvl = level(lvl)
