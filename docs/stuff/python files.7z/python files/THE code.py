from pynput.keyboard import Key, Controller
from time import *
k = Controller()
def p(key1):
    k.press(key1)
    k.release(key1)
while True:
    p('t')
    p('h')
    p('e')
    p(Key.space)
    sleep(0.1)
