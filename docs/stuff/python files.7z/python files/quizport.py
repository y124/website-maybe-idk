from random import *
import math

def root(num):
    num = math.sqrt(num)
    num = int(num)
    return num


def root_q(num, p):
    e = root(num)
    a = randint(1, e)
    b = input('What is the square root of ' + str(a*a) + '? ')
    if str(a) == b:
        p = p + 1
    return p


def times(num, p):
    e = root(num)
    a = randint(1, e)
    b = randint(1, e)
    e = input("What is " + str(a) + "x" + str(b) + "? ")
    if str(a*b) == e:
        p = p + 1
    return p


def plus(num, p):
    a = randint(1, (num - 1))
    b = randint(1, (num - a))
    e = input("What is " + str(a) + "+" + str(b) + "? ")
    if str(a+b) == e:
        p = p + 1
    return p


def minus(num, p):
    a = randint(1, num)
    b = randint(1, a)
    e = input("What is " + str(a) + "-" + str(b) + "? ")
    if str(a-b) == e:
        p = p + 1
    return p


def divide(num, p):
    v = 0
    a = randint(1, num)
    b = randint(1, a)
    while v == 0:
        if a/b == float(int(a/b)) and int(a/b) != 1 and int(a/b) != a:
            e = input("What is " + str(a) + "÷" + str(b) + "? ")
            if str(int(a/b)) == e:
                p = p + 1
            v = 1
        else:
            a = randint(1, num)
            b = randint(1, a)
    return p


def power(a, b):
    e = 1
    for count in range(b):
        e = a*e
    return e


def power_max(num):
    e = 1
    while((int(num) != int(2)) and (int(num) != int(3))):
        num = num/2
        e = e + 1
    return e


def power_q_(a, b, p, num):
    try:
        if int(power(a, b)) <= int(num):
            z = input("What is " + str(a) + '^' + str(b) + "? ")
            if z == str(power(a, b)):
                p = p + 1
        else:
            p = power_q_(a, (b - 1), p, num)
        return p
    except RecursionError:
        input("ERROR 68240: Lazy powers code stops working if your unlucky and good please try again")


def power_q(num, p):
    f = power_max(num)
    a = randint(1, f)
    b = randint(1, f)
    if int(power(a, b)) <= int(num):
        z = input("What is " + str(a) + '^' + str(b) + "? ")
        if z == str(power(a, b)):
            p = p + 1
    else:
        p = power_q_(a, (b - 1), p, num)
    return p

def randquiz(num, p, types):
    f = randint(1, types)
    if f == 1:
        p = plus(num, p)
    if f == 2:
        p = minus(num, p)
    if f == 3:
        p = times(num, p)
    if f == 4:
        p = divide(num, p)
    if f == 5:
        p = root_q(num, p)
    if f == 6:
        p = power_q(num, p)
    return p
