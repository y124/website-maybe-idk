import smtplib
from random import *
while True:
    server = smtplib.SMTP(host='smtp.gmail.com', port=587)
    server.ehlo()
    server.starttls()
    server.login('dallyspam14@gmail.com', 'Dally69420')
    a = ''
    for cout in range(25):
        a += chr(randint(1, 127))
    subject = a
    a = ''
    for cout in range(1000):
        a += chr(randint(1, 127))
    body = a
    message = f'Subject: {subject}\n\n{body}'
    server.sendmail('dallyspam14@gmail.com', 'angus.g.rose@gmail.com', message)
    server.quit()
