from pynput.keyboard import Key, Controller
from random import *
from time import *
keyboard = Controller()
sleep(1)
for count in range(10):
    for count in range(10):
        guess = str(randint(10000, 99999))
        keyboard.type(str(guess))
        print(guess)
        for count in range(10):
            keyboard.press(str(count))
            keyboard.release(str(count))
            keyboard.press(Key.enter)
            keyboard.release(Key.enter)
            sleep(random()*5)
            keyboard.press(Key.backspace)
            keyboard.release(Key.backspace)
        keyboard.press(Key.backspace)
        keyboard.release(Key.backspace)
        keyboard.press(Key.backspace)
        keyboard.release(Key.backspace)
        keyboard.press(Key.backspace)
        keyboard.release(Key.backspace)
        keyboard.press(Key.backspace)
        keyboard.release(Key.backspace)
        keyboard.press(Key.backspace)
        keyboard.release(Key.backspace)
        keyboard.press(Key.backspace)
        keyboard.release(Key.backspace)
        sleep(1)    
