from tkinter import *
from tkinter.font import Font
from math import sqrt
LOGGED = ''
ROOT = Tk()

myFont = Font(family="Times New Roman", size=25)
def logg(itemaa):
    global LOGGED
    LOGGED = LOGGED+itemaa
    lbl.configure(text=LOGGED)

def nothing():
    pass

def backspace():
    global LOGGED
    LOGGED = LOGGED[:-1]
    lbl.configure(text=LOGGED)

def clear():
    global LOGGED
    LOGGED = ''
    lbl.configure(text=LOGGED)

def equals():
    global LOGGED
    LOGGED = eval(LOGGED)
    LOGGED = str(LOGGED)
    lbl.configure(text=LOGGED)
    
btn=Button(ROOT, text ="1", command = lambda: logg('1'), width=10 , bg='red')
btn.grid(row=0, column=0)
btn.configure(font=myFont)
btn=Button(ROOT, text ="2", command = lambda: logg('2'), width=10 , bg='orange')
btn.grid(row=1, column=0)
btn.configure(font=myFont)
btn=Button(ROOT, text ="3", command = lambda: logg('3'), width=10 , bg='yellow')
btn.grid(row=2, column=0)
btn.configure(font=myFont)
btn=Button(ROOT, text ="+", command = lambda: logg('+'), width=10 , bg='green')
btn.grid(row=3, column=0)
btn.configure(font=myFont)
btn=Button(ROOT, text ="x", command = lambda: logg('*'), width=10 , bg='blue')
btn.grid(row=4, column=0)
btn.configure(font=myFont)

btn=Button(ROOT, text ="4", command = lambda: logg('4'), width=10 , bg='orange')
btn.grid(row=0, column=1)
btn.configure(font=myFont)
btn=Button(ROOT, text ="5", command = lambda: logg('5'), width=10 , bg='yellow')
btn.grid(row=1, column=1)
btn.configure(font=myFont)
btn=Button(ROOT, text ="6", command = lambda: logg('6'), width=10 , bg='green')
btn.grid(row=2, column=1)
btn.configure(font=myFont)
btn=Button(ROOT, text ="-", command = lambda: logg('-'), width=10 , bg='blue')
btn.grid(row=3, column=1)
btn.configure(font=myFont)
btn=Button(ROOT, text ="'/.", command = lambda: logg('/'), width=10 , bg='purple')
btn.grid(row=4, column=1)
btn.configure(font=myFont)

btn=Button(ROOT, text ="7", command = lambda: logg('7'), width=10 , bg='yellow')
btn.grid(row=0, column=2)
btn.configure(font=myFont)
btn=Button(ROOT, text ="8", command = lambda: logg('8'), width=10 , bg='green')
btn.grid(row=1, column=2)
btn.configure(font=myFont)
btn=Button(ROOT, text ="9", command = lambda: logg('9'), width=10 , bg='blue')
btn.grid(row=2, column=2)
btn.configure(font=myFont)
btn=Button(ROOT, text ="backspace", command = backspace, width=10 , bg='purple')
btn.grid(row=3, column=2)
btn.configure(font=myFont)
btn=Button(ROOT, text ="equals", command = equals, width=10 , bg='red')
btn.grid(row=4, column=2)
btn.configure(font=myFont)

btn=Button(ROOT, text ="(", command = lambda: logg('('), width=10 , bg='green')
btn.grid(row=0, column=4)
btn.configure(font=myFont)
btn=Button(ROOT, text =")", command = lambda: logg(')'), width=10 , bg='blue')
btn.grid(row=1, column=4)
btn.configure(font=myFont)
btn=Button(ROOT, text ="squareroot", command = lambda: logg('sqrt('), width=10 , bg='purple')
btn.grid(row=2, column=4)
btn.configure(font=myFont)
btn=Button(ROOT, text ="to the power of", command = lambda: logg('^'), width=10 , bg='red')
btn.grid(row=3, column=4)
btn.configure(font=myFont)
btn=Button(ROOT, text = "clear", command = clear, width=10 , bg='orange')
btn.grid(row=4, column=4)
btn.configure(font=myFont)

lbl = Label(text='')
lbl.grid(row=6, column=0)
lbl.configure(font=myFont)

ROOT.mainloop()
