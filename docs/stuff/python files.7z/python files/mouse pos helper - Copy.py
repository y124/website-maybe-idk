from pynput.mouse import Button, Controller
from time import *
mouse = Controller()
def pos(per2x, per2y):
    x = int(per2x*12.8)
    y = int(per2y*7.2)
    mouse.position = (x, y)
pos(50, 50)
