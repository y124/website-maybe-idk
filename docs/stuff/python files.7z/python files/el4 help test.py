import pynput.keyboard as pykey
import pynput.mouse as pymouse
mouse = pymouse.Controller()
els = ['air', 'earth', 'fire', 'water']
sq1 = [(9, 154), (87, 237)]

import pyscreenshot as ImageGrab
im=ImageGrab.grab(bbox=(9, 154,87, 237))
im.save('image_01.png')

from PIL import Image
import pytesseract
import numpy as np
filename = 'image_01.png'
img1 = np.array(Image.open(filename))
text = pytesseract.image_to_string(img1)
print(text)
