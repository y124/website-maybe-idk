from random import *
l = []
l2 = []
n = 7
for count in range(10000):
    c = randint(1, 6) + randint(1, 6) + randint(1, 6) + randint(1, 6) + randint(1, 6) + randint(1, 6) + randint(1, 6) + randint(1, 6)
    l.append(c)
for count in range(41):
    n = n + 1
    d = 0
    for count in range(10000):
        if (l[count] == n):
            d = d + 1
    l2.append(d)
print(l2)
input()
