from time import *
sleporlev = 'on'
kht = input('which kahoot: ')
ee = input('amount of seconds given per question: ')
file = open(str(kht + ".txt"),"r") # opens your kahoot
kahoot = file.readlines() # reads the kahoot
for count in range(len(kahoot)): # if i tried to explain you wouldn't get it
    kahoot[count] = kahoot[count][0:len(kahoot[count]) - 1] # i don't even know but it works!
q = kahoot[0] # questions
uptoline = 2 # line the code is up to on your kahoot
AS = 0 # answer streak
score = 0
for count in range(int(q)): # starts the kahoot
    PAoL = int(kahoot[uptoline]) # PAoL = print amount of lines
    for count in range(PAoL): # makes sure you print the right lines
        uptoline = uptoline + 1 # moves to next line
        if sleporlev == 'on':
            sleep(0.5) # so you dont get a block of text all at once
        print(kahoot[uptoline]) # print what the text document wants
    if sleporlev == 'on':
        sleep(0.5)
    t = time() 
    e = input('Your answer is: ') # asks for your answer
    t2 = time()
    timee = t2 - t # times you
    uptoline = uptoline + 1  # moves to next line
    if kahoot[uptoline] == e: # if you win.
        if sleporlev == 'on':
            sleep(0.5)
        print('correct!!')
        s = int(((float(ee) - timee)*(1000/float(ee)))*(1 + (0.1*AS))) # works out score
        score = score + s # adds score to total
        if sleporlev == 'on':
            sleep(0.5)
        print('score: ' + str(s) + '   total: ' + str(score))
        if sleporlev == 'on':
            sleep(0.5)
        AS = AS + 1 # adds one to answer streak
        print('answer streak: ' + str(AS))
    else: # if you lose.
        if sleporlev == 'on':
            sleep(0.5)
        print('incorrect.')
        if sleporlev == 'on':
            sleep(0.5)
        print('score: ' + str(score))
        if sleporlev == 'on':
            sleep(0.5)
        print('answer streak lost')
        AS = 0 # deletes answer streak
    if sleporlev == 'on':
        sleep(0.5)
    print() # seperating the questions
    uptoline = uptoline + 2 # moving to next question
input('great job your score is: ' + str(score))
