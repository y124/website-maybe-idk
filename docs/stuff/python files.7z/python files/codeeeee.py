from PIL import Image, ImageDraw, ImageFont
circle1 = ['q', 'e', 'o', 'p', 'a', 'd', 'g', 'b']
lines1 = ['w', 'r', 't', 'y', 'u', 'i', 's', 'f', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'n', 'm']
dot1 = ['i', 'j']
a = input('>>> ')
a = a.lower()
aa = []
abab = []
bb = []
ab = a+a+a
for b in a:
 aa.append(ord(b))
for c in ab:
 abab.append(ord(c))
aa2 = []
for i in range(int(len(aa)/3)):
    bb.append((aa[i*3], aa[i*3+1], aa[i*3+2]))
for n in aa:
    if n > 60:
        aa2.append(n - 60)
aa = aa2
out = Image.new('RGB', (sum(aa), sum(aa)), 'black')
draw = ImageDraw.Draw(out)
c = 0
for i in range(len(aa)):
    n = aa[i]
    nn = chr(n+60)
    if nn in circle1: 
        draw.ellipse([(c, 0), (c+n, int(n*len(aa)/3))], fill=(abab[i*3], abab[i*3+1], abab[i*3+2]))
    else:
        draw.rectangle([(c, 0), (c+n, int(n*len(aa)/2))], fill=(abab[i*3], abab[i*3+1], abab[i*3+2]))
    if nn in dot1:
        draw.ellipse([(c+n/3, 0), (c+(n/3*2), n/3)], fill=(abab[i*3+2], abab[i*3], abab[i*3+1]))
    c += n
f = out.load()
for tri in bb:
    draw.polygon([(out.size[1]-tri[0], out.size[1]-tri[1]),(out.size[1]-tri[1], out.size[1]-tri[2]),(out.size[1]-tri[2], out.size[1]-tri[0])], fill=(tri[2], tri[0], tri[1]))
for i in range(out.size[0]):
    for j in range(out.size[1]):
        if f[i, j] == (0, 0, 0):
            f[i, j] = bb[int(j/10)%(len(bb))]

an = (0, int(out.size[1]/5)*4)
ff = (ord(a[1]), 0, ord(a[3]))
draw.rectangle([an,(int(out.size[0]/5), out.size[1])], fill=ff)

out.show()
