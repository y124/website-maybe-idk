b = 0
for count in range(12):
    a = (count + 1)*(count + 2)
    b = a + b
    print(b)
