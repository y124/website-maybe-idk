#importing stuff
from tkinter import *
from tkinter.ttk import *
from tkinter.font import Font
from random import *

# import save
save = open('items.txt', 'r') 
items = save.read().split('\n')
save.close()
root = Tk()
myFont = Font(family="Times New Roman", size=25)
myFontSmall = Font(family="Times New Roman", size=10)
coin = int(items[1])
common = int(items[2])
uncommon = int(items[3])
rare = int(items[4])
epic = int(items[5])
legendary = int(items[6])
ShowItems = Toplevel(root)
Upgrades = Toplevel(root)

# empty command for buttons that do nothing
def empty():
    return

# random loot
def clicked():
    global coin
    global common
    global uncommon
    global rare
    global epic
    global legendary
    loot = randint(1, 10000)
    if loot > 1000:
        coin += 1
        lbl1.configure(text=str(coin))
    elif loot > 250:
        common += 1
        lbl2.configure(text=str(common))
    elif loot > 100:
        uncommon += 1
        lbl3.configure(text=str(uncommon))
    elif loot > 25:
        rare += 1
        lbl4.configure(text=str(rare))
    elif loot > 10:
        epic += 1
        lbl5.configure(text=str(epic))
    else:
        legendary += 1
        lbl6.configure(text=str(legendary))
    file = open('items.txt', 'w')
    file.write('ITEMS' + '\n')
    file.write(str(coin) + '\n')
    file.write(str(common) + '\n')
    file.write(str(uncommon) + '\n')
    file.write(str(rare) + '\n')
    file.write(str(epic) + '\n')
    file.write(str(legendary) + '\n') 
    file.close() 

# Click Button Setup
photo = PhotoImage(file = r"Click.png")
btn=Button(root, command = clicked, width=10, image=photo)
btn.grid(row=0, column=0)
lbl = Label(text='Click!')
lbl.grid(row=1, column=0)
lbl.configure(font=myFont)

#Items List
photo1 = PhotoImage(file = r"Coin.png")
btn=Button(ShowItems, command = empty, width=10, image=photo1)
btn.grid(row=0, column=0)
lbl1 = Label(ShowItems, text=str(coin))
lbl1.grid(row=0, column=1)
lbl1.configure(font=myFont)

photo2 = PhotoImage(file = r"Common.png")
btn=Button(ShowItems, command = empty, width=10, image=photo2)
btn.grid(row=1, column=0)
lbl2 = Label(ShowItems, text=str(common))
lbl2.grid(row=1, column=1)
lbl2.configure(font=myFont)

photo3 = PhotoImage(file = r"Uncommon.png")
btn=Button(ShowItems, command = empty, width=10, image=photo3)
btn.grid(row=2, column=0)
lbl3 = Label(ShowItems, text=str(uncommon))
lbl3.grid(row=2, column=1)
lbl3.configure(font=myFont)

photo4 = PhotoImage(file = r"Rare.png")
btn=Button(ShowItems, command = empty, width=10, image=photo4)
btn.grid(row=0, column=3)
lbl4 = Label(ShowItems, text=str(rare))
lbl4.grid(row=0, column=4)
lbl4.configure(font=myFont)

photo5 = PhotoImage(file = r"Epic.png")
btn=Button(ShowItems, command = empty, width=10, image=photo5)
btn.grid(row=1, column=3)
lbl5 = Label(ShowItems, text=str(epic))
lbl5.grid(row=1, column=4)
lbl5.configure(font=myFont)

photo6 = PhotoImage(file = r"Legendary.png")
btn=Button(ShowItems, command = empty, width=10, image=photo6)
btn.grid(row=2, column=3)
lbl6 = Label(ShowItems, text=str(legendary))
lbl6.grid(row=2, column=4)
lbl6.configure(font=myFont)

root.mainloop()
