from random import *
def f(q, w, e, t, r):
    if((q + w + e + r + t) == 0):
        return 0
    else:
        return 1
p = True
while(p == True):
    b = []
    a = []
    e = 0
    g = 0
    for count in range(25):
        a.append(count - 13)
    for count in range(25):
        c = randint(0, (24 - count))
        b.append(a[c])
        a.remove(a[c])
    for count in range(5):
        d = f(b[1 + (5 * (count - 1))], b[2 + (5 * (count - 1))], b[3 + (5 * (count - 1))], b[4 + (5 * (count - 1))], b[5 + (5 * (count - 1))])
        e = e + d
    for count in range(5):
        d = f(b[1*count], b[2*count], b[3*count], b[4*count], b[5*count])
        g = g + d
        if(e == 0):
            if(g == 5):
                print('hi')
    d = f(b[0], b[6], b[12], b[18], b[24])
    e = e + d
    d = f(b[4], b[8], b[12], b[16], b[20])
    e = e + d
    e = e + g
    if e == 1:
        print(b)
        p = False
