from pynput.mouse import Button, Controller
from time import *
mouse = Controller()
sleep(5)
for count in range(1000):
    mouse.press(Button.left)
    mouse.release(Button.left)
    sleep(0.01)
