from pynput.mouse import *
from time import *
m = Controller()
def pos(per2x, per2y):
    x = int(per2x*12.8)
    y = int(per2y*7.2)
    m.position = (x, y)
def p(x, y):
    pos(x, y)
    sleep(0.1)
    m.press(Button.left)
    sleep(0.1)
    m.release(Button.left)


p(0,100)
sleep(0.7)
p(22,94)
sleep(0.7)
p(16,72)
sleep(0.7)
p(16,68)
sleep(0.7)
p(16,78)
sleep(0.7)
p(27,60)
p(27,60)
sleep(0.7)
p(60,28)
sleep(1.7)
p(9,40)
