from pynput.mouse import *
mouse = Controller()
while True:
    print(mouse.position)



