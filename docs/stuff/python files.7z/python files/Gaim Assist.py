from random import *
bal = 100
ppt = 10
print("start any message relalated to points per turn with 't' and any relating to being attacked with 'a'")
print("(if your points per turn is attacked use 'ta')")
print('use the format (examples: +12 +10% -16 t+5 a60 ta5 s)')
print("to open shop use 's'")
while True:
    print("balance is " + str(bal) + " and " + str(ppt) + " added per turn")
    a = input('> ')
    b = a[0]
    c = 1
    d = ''
    for count in range(len(a) - 1):
        d = d + a[c]
        c = c + 1
    a = d
    if b == '+':
        if(a[-1] != '%'):
            a = float(a)
            bal = bal + a
        else:
            c = 0
            d = ''
            for count in range(len(a) - 1):
                d = d + a[c]
                c = c + 1
            a = d
            bal = bal * (1 + float(a)/100)

    if b == '-':
        if(a[-1] != '%'):
            a = float(a)
            bal = bal - a
        else:
            c = 0
            d = ''
            for count in range(len(a) - 1):
                d = d + a[c]
                c = c + 1
            a = d
            bal = bal - ((bal/100)*float(a))

    if b == 'a':
        if bal - float(a) < 0:
            bal = 0
        else:
            bal = bal - float(a)

    if b == '*' or b == 'x':
        if(a[-1] != '%'):
            a = float(a)
            bal = bal*a
        else:
            c = 0
            d = ''
            for count in range(len(a) - 1):
                d = d + a[c]
                c = c + 1
            a = d
            bal = bal * (bal/100)

    if b == '/':
        bal = bal/float(a)

    if b == 'r':
        print(str(randint(1, 6)) + ' was your roll, ' + str(ppt) + ' successfully added to your score')
        bal = bal + ppt

    if b == 't':
        b = a[0]
        c = 1
        d = ''
        for count in range(len(a) - 1):
            d = d + a[c]
            c = c + 1
        a = d
        a = float(a)
        if b == '+':
            ppt = ppt + a
        if b == '-':
            ppt = ppt - a
        if b == 'a':
            if ppt - float(a) < 0:
                ppt = 0
            else:
                ppt = ppt - float(a)
        if b == '=':
            bal = float(a)

    if b == '=':
        bal = float(a)

    if b == 's':
        a = a + '#'
        e = a[0]
        if e == 't':
            print('Points per turn shop:')
            print('0.5 ppt for 10 use p1 to buy!')
            print('6 ppt for 100 use p2 to buy!')
            print('75 ppt for 1000 use p3 to buy!')
        elif e == 'g':
            print('Gambling shop:')
            print('roll the dice the reward is yours')
            print('LOSSES: 1 = x0, 2 = x0.1, 3 = x0.5')
            print('WINS: 4 = Money back, 5 = x1.3, 6 = x2')
            print('to use pgAMOUNT to gamble it!')
        elif e == 'a':
            print('Attack shop:')
            print('Attack of 5 for 10 use p4 to buy!')
            print('Attack of 60 for 100 use p5 to buy!')
            print('Attack of 650 for 1000 use p6 to buy!')
            print('Attack of 5 points per turn for 100 use p7 to buy!')
            print('Can not bring player below 0')
        else:
            print('Welcome to the shop')
            print("Use 'st' for points per turn (ppt) shop")
            print("'sg' for gambling shop")
            print("or 'sa' for attack shop")

    if b == 'p':
        e = a[0]
        if e == '1':
            if bal-10 > 0:
                bal = bal-10
                ppt = ppt+0.5
                print('Success')
            else:
                print("CAN'T AFFORD ITEM")
        if e == '2':
            if bal-100 > 0:
                bal = bal-100
                ppt = ppt+6
                print('Success')
            else:
                print("CAN'T AFFORD ITEM")
        if e == '3':
            if bal-1000 > 0:
                bal = bal-1000
                ppt = ppt+75
                print('Success')
            else:
                print("CAN'T AFFORD ITEM")
        if e == '4':
            if bal-10 > 0:
                bal = bal-10
                print('Success ask another player to use a5')
            else:
                print("CAN'T AFFORD ITEM")
        if e == '5':
            if bal-100 > 0:
                bal = bal-100
                print('Success ask another player to use a60')
            else:
                print("CAN'T AFFORD ITEM")
        if e == '6':
            if bal-1000 > 0:
                bal = bal-1000
                print('Success ask another player to use a650')
            else:
                print("CAN'T AFFORD ITEM")
        if e == '7':
            if bal-100 > 0:
                bal = bal-100
                print('Success ask another player to use ta5')
            else:
                print("CAN'T AFFORD ITEM")
        if e == 'g':
            c = 1
            d = ''
            for count in range(len(a) - 1):
                d = d + a[c]
                c = c + 1
            a = d
            if a[-1] == '%':
                c = 0
                d = ''
                for count in range(len(a) - 1):
                    d = d + a[c]
                    c = c + 1
                a = d
                a = (bal/100)*float(a)
            a = float(a)
            if bal-a > 0:
                bal = bal-a
                f = randint(1, 6)
                print('you rolled a ' + str(f) + '!')
                if f == 1:
                    print('You got nothing!')
                if f == 2:
                    print('you multiplyed your money by 0.1!')
                    bal = bal+(a*0.1)
                if f == 3:
                    print('you multiplyed your money by 0.5!')
                    bal = bal+(a*0.5)
                if f == 4:
                    print('you won your money back!')
                    bal = bal+(a*1)
                if f == 5:
                    print('you multiplyed your money by 1.3!')
                    bal = bal+(a*1.3)
                if f == 6:
                    print('you multiplyed your money by 2!')
                    bal = bal+(a*2)
            else:
                print("CAN'T AFFORD ITEM")
